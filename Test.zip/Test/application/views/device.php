<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
if(isset($result) && count($result)>0) {
	$viewContent = $jsonContent = "";
	$ajax = $result['ajax'];
	unset($result['ajax']);
	$jsonContent = '<tr><td colspan="4">'.$result['json'].'</td></tr>';
	unset($result['json']);
	foreach($result as $index=>$device) {
		$viewContent .= "<tr>
							<td>".$device['deviceid']."</td>
							<td>".ucfirst($device['devicelabel'])."</td>
							<td>".$device['reporttime']."</td>";
							if($device['devicestatus'] == "GREEN") {
								$viewContent .= "<td style='color:green;'>OK</td>";
							} else {
								$viewContent .= "<td style='color:red;'>OFFLINE</td>";
							}
						$viewContent .= "</tr>";
	}
	
	if($ajax == 1) {
		echo json_encode(array('viewcont'=>$viewContent, 'jsoncont'=>$jsonContent)); exit;
	}
}
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to DeviceInfoProvider</title>
	<link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>	
    <script type = 'text/javascript' src = "<?php echo base_url(); ?>js/device.js"></script> 
</head>
<body>

<div id="container">
	<h1>Welcome to Device Info Provider!</h1>

	<div id="body">
		<form method="post" name="deviceDetailsFrm" id="deviceDetailsFrm" >
			<table id="dip_filter" class="table">
				<tbody><tr>
					<td><input type="text" name="device_id" id="device_id" /></td>
					<td><select name="device_label" id="device_label">
						<option value=""> Select Label </option>
						<option value="samsung"> Samsung </option>
						<option value="micromax"> Micromax </option>
						<option value="sony"> Sony </option>
						<option value="lg"> LG </option>
					</select></td>
					<td><input type="button" name="device_report" id="device_report" value="Report"/></td>
					<td style="color:red;">It will update the Last Date and Time for the Device</td>
				</tr></tbody>
			</table>
			<br/><br/>
			<table id="dip_filter" class="table">
				<thead>
					<tr><th colspan="4">HTML OUTPUT</th></tr>
					<tr>
					<td> Device ID </td>
					<td> Device Label </td>
					<td> Last Report Time </td>
					<td> Status </td>
				</tr></thead>
				<tbody id="device_details"><?=$viewContent;?></tbody>
				<tfoot id="device_json"><?=$jsonContent;?></tfoot>
				<tfoot><tr><th colspan="4"> JSON OUTPUT </th></tr></tfoot>
			</table>
		</form>
	</div>
</div>

</body>
</html>