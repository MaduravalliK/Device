<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Device extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/device
	 *	- or -
	 * 		http://example.com/index.php/device/index
	 */
	
	function __construct() {
		parent::__construct(); 
		$this->load->database(); 
	}
	public function index()
	{
		$data = array('result'=>$this->devicedetails());
		return $this->load->view('device', $data);
	}
	
	public function info()
	{
		$input = $this->input->get();
		if(count($input)>0 && isset($input['device_id']) && !empty($input['device_id'])) {
			$query 			= $this->db->query('select * from device_info where status="1" order by id desc');
			$result 		= $query->result();
			$deviceid 		= $input['device_id'];
			$devicelabel	= $input['device_label'];
			$reporttime 	= date("Y-m-d H:i:s");
			if(!$result) {
				$blobContent = '<?xml version="1.0" encoding="UTF-8"?><devices><device label="'.$devicelabel.'" id="'.$deviceid.'" reporttime="'.$reporttime.'" status="1" /></devices>';
				$data 		 = array( 'device_details' => $blobContent, 'inserted_date' => $reporttime ); 
				$this->db->insert("device_info", $data);
			} else {
				$deviceDetails  = $result[0]->device_details;
				$ddom 			= new DOMDocument();
				$ddom->loadXML($deviceDetails);
				$xpath 			= new DOMXpath($ddom);
				$devicesNodes 	= $xpath->query("//devices");
				if($devicesNodes->length > 0) {
					$devices = $devicesNodes->item(0);
				}
				$deviceNodes 	= $xpath->query("//device[@label='".$devicelabel."'][@id='".$deviceid."'][last()]");
				if(!$deviceNodes->length > 0) {
					$device 	= $ddom->createElement("device");
					$device->setAttribute('label', $devicelabel);
					$device->setAttribute('id', $deviceid);
					$device->setAttribute('reporttime', $reporttime);
					$device->setAttribute('status', "1");
					$devices->appendChild($device);
					$blobContent = $ddom->saveXML();
				} else {
					$deviceNode = $deviceNodes->item(0);
					$reptime 	= $deviceNode->getAttribute('reporttime');
					$date1 		= date_create($reptime);
					$date2 		= date_create($reporttime);
					$diff 		= date_diff($date1,$date2);
					$differs 	= $diff->format("%a");
					if($differs < 2) {
						$status = "1";
					}	else {
						$status = "0";
					}
					$device 	= $ddom->createElement("device");
					$device->setAttribute('label', $devicelabel);
					$device->setAttribute('id', $deviceid);
					$device->setAttribute('reporttime', $reporttime);
					$device->setAttribute('status', $status);
					$devices->appendChild($device);
					$blobContent = $ddom->saveXML();
				}
				$data = array( 'device_details' => $blobContent); 
				$this->db->set($data); 
				$this->db->where("status", "1"); 
				$this->db->update("device_info", $data);
			}
		}
		$data = array('result'=>$this->devicedetails(1));
		return $deviceinfo = $this->load->view('device', $data, true);
	}
	
	public function devicedetails($ajax=0) {
		$query 		= $this->db->query('select * from device_info where status="1" order by id desc');
		$result 	= $query->result();
		$retdata 	= array();
		if($result) {
			$deviceDetails	= trim($result[0]->device_details);
			$ddom 	= new DOMDocument();
			$ddom->loadXML($deviceDetails);
			$xpath 	= new DOMXpath($ddom);
			$deviceNodes 	= $xpath->query("//device");
			if($deviceNodes->length > 0) {
				foreach($deviceNodes as $index=>$device) {
					$retdata[$index]['devicelabel'] 	= $device->getAttribute('label');
					$retdata[$index]['deviceid'] 		= $device->getAttribute('id');
					$retdata[$index]['reporttime'] 		= $device->getAttribute('reporttime');
					$retdata[$index]['devicestatus'] 	= ($device->getAttribute('status') == "1")?"GREEN":"RED";
				}
			}
		}
		$retdata['json'] = json_encode($retdata);
		$retdata['ajax'] = $ajax;
		return $retdata;
	}
}
