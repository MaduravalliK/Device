$(document).ready(function(){
    $("#device_report").on('click', function(){
		var deviceid = $.trim($("#device_id").val());
		var devicelabel = $.trim($("#device_label").val());
		if(deviceid == '') {
			$("#device_id").css('borderColor', 'red');
			return false;
		}
		if(devicelabel == '') {
			$("#device_label").css('borderColor', 'red');
			return false;
		}
		var data = $("#deviceDetailsFrm").serialize();
        $.ajax({
			url: "device/info", 
			data: data,
			success: function(result){
				obj = JSON.parse(result);
				$("#device_details").html(obj.viewcont);
				$("#device_json").html(obj.jsoncont);
				return false;
			}
		});
    });
});